#!/usr/bin/env sh
cd -- "$(dirname -- "$0")" || exit 1
exec ./V_mini_me_launcher
