V_mini_me Windows x86-64 functional-parity test build

Recommended start: double-click V_mini_me_launcher.exe
Direct core start: double-click V_mini_me.exe

Function is translated from the Linux release using Windows-native equivalents:
- same config.ini keys and avatar folder layout
- same direction modes, deadzone and mouse tracking behavior
- microphone reaction and talking PNG fallback
- talking bounce, idle bob and idle sway
- Quick Expressions slots and live switching
- avatar/expression folder picker
- Save / Start / Reload / Stop workflow

Windows implementation:
- core: native Win32/GDI+/WinMM
- launcher: raylib 6.0 built with the same MinGW toolchain + Win32 process/pipe control

Initial target: Windows 10/11 x86-64.
